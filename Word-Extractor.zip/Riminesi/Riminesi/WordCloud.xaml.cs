﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WordCloudGen = WordCloud.WordCloud;

namespace Riminesi
{
    /// <summary>
    /// Logica di interazione per WordCloud.xaml
    /// </summary>
    public partial class WordCloud : Window
    {
        public WordCloud(Dictionary<string, uint> occorrenze)
        {
            InitializeComponent();
            List<string> s = new List<string>();
            List<int> i = new List<int>();
            var wc = new WordCloudGen(612, 399);
            foreach (var item in occorrenze.OrderByDescending(key => key.Value))
            {
                s.Add(item.Key);
                i.Add((int)item.Value);
            }
            image.Source = GetImageStream(wc.Draw(s, i));
        }
        private BitmapSource GetImageStream(System.Drawing.Image myImage)
        {
            var bitmap = new Bitmap(myImage);
            IntPtr bmpPt = bitmap.GetHbitmap();
            BitmapSource bitmapSource =
             System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                   bmpPt,
                   IntPtr.Zero,
                   Int32Rect.Empty,
                   BitmapSizeOptions.FromEmptyOptions());

            //freeze bitmapSource and clear memory to avoid memory leaks
            bitmapSource.Freeze();
            DeleteObject(bmpPt);

            return bitmapSource;
        }
        [DllImport("gdi32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool DeleteObject(IntPtr value);

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }
    }
}
