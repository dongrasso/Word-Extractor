﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Riminesi
{
    /// <summary>
    /// Logica di interazione per MyDialog.xaml
    /// </summary>
    public partial class MyDialog : Window
    {
        public MyDialog()
        {
            InitializeComponent();
        }
        public MyDialog(Dictionary<string, uint> dic)
        {
            InitializeComponent();

            List<occorrenza> grid = new List<occorrenza>();
            foreach (var item in dic.OrderByDescending(key => key.Value))
            {
                occorrenza o = new occorrenza(item.Key, item.Value);
                grid.Add(o);
            }
            GridView.ItemsSource = grid;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        class occorrenza
        {
            public occorrenza(string key, uint value)
            {
                this.Parola = key;
                this.Frequenza = value;
            }

            public string Parola { get; set; }
            public uint Frequenza { get; set; }
        }
    }
}
