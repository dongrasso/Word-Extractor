﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Riminesi
{
    /// <summary>
    /// Logica di interazione per GetFromDb.xaml
    /// </summary>
    public partial class GetFromDb : Window
    {
        public string ReturnValue1 { get; set; }

        string path = Environment.CurrentDirectory;
        string connectionstring;
        public GetFromDb()
        {
            InitializeComponent();
            List<db> listadb = new List<db>();
            path = path.Substring(0, path.Length - 9);
            connectionstring = string.Format(@"Server=(localdb)\MSSQLLocalDB;AttachDbFilename=" + path + "Database.mdf;Integrated Security=True;Persist Security Info=False;Pooling=False;MultipleActiveResultSets=False;Encrypt=False;TrustServerCertificate=False");

            //SqlConnection SCq = new SqlConnection(connectionstring);
            //SCq.Open();
            //SqlCommand cmd = new SqlCommand("dbo.art_count", SCq);
            //cmd.CommandType = System.Data.CommandType.StoredProcedure;
            //Int32 count = (Int32)cmd.ExecuteScalar();
            //SCq.Close();

            string queryString = "SELECT link, html FROM  [dbo].[Articoli]";
            using (SqlConnection SC = new SqlConnection(connectionstring))
            {
                SqlCommand command = new SqlCommand(queryString, SC);

                SC.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    //link.Add((string)reader["link"]);
                    //grass.Add((string)reader["html"]);
                    db elementi = new db((string)reader["link"]);
                    listadb.Add(elementi);
                }
            }
            GridDb.ItemsSource = listadb;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }
        class db
        {
            public db(string link)
            {
                Link = link;
            }

            public string Link { get; set; }
            public override string ToString()
            {
                return string.Format(Link);
            }
        }

        private void Html_Click(object sender, RoutedEventArgs e)
        {
            if (GridDb.SelectedIndex > -1)
            {
                var x = GridDb.SelectedItem.ToString(); ;
                DialogResult = true;
                string queryString = "SELECT html FROM  [dbo].[Articoli] WHERE link = @url";
                using (SqlConnection SC = new SqlConnection(connectionstring))
                {
                    SqlCommand command = new SqlCommand(queryString, SC);
                    command.Parameters.AddWithValue("@url", x);
                    SC.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string s = ((string)reader["html"]);
                        var h = new html(ref s);
                        h.ShowDialog();
                    }
                }
            }
            else
            {
                MessageBox.Show("Selezione un elemento nella grid");
            }
        }
    }
}
