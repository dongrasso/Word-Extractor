﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Web;
using HtmlAgilityPack;
using System.Net;
using System.Data.SqlClient;
using System.Data;
using mshtml;
using System.Diagnostics;

namespace Riminesi
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Dichiarazione variabili, dizionari e liste.
        private Dictionary<string, uint> Occorrenze;
        private Dictionary<string, string> Url;
        string Xpath = "";
        string UrlCheck = "";
        string prova = "";
        string [] dominio;
        List<string> ParoleChiave;
        string grassetto="";
        public MainWindow()
        {
            InitializeComponent();
            LoadXpath(ref Url);
            foreach (var item in Url)
            {
                dominio = item.Key.Split('/');
                ListaSiti.Items.Add(dominio[0]);
            }
        }

        //Metodo per restituire il testo con i tag <strong></strong> per riavere il testo con le parole in grassetto in html.
        private void ToStrong(ref HtmlDocument doc , ref string sos)
        {
            var nodes = doc.DocumentNode.SelectSingleNode(Xpath).Descendants();
            string[] vet = doc.Text.Split(' ');
            for (int i = 0; i < vet.Length; i++)
            {
                vet[i] = vet[i].Replace("<strong>", " ");
                vet[i] = vet[i].Replace("</strong>", " ");
            }
            foreach (var item in vet)
            {
                if (ParoleChiave.Contains(item.ToUpper()))
                {
                    sos += " <strong>" + item + "</strong> ";
                }
                else
                {
                    sos += " " + item;
                }
            }
        }

        private void Avvia_Click(object sender, RoutedEventArgs e)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            if (!string.IsNullOrEmpty(Link.Text))
            {
                UrlCheck = Link.Text;
                if (!UrlCheck.Contains("http://") && !UrlCheck.Contains("https://"))
                {
                    UrlCheck = "http://" + UrlCheck;
                }
                try
                {
                    WebRequest req = WebRequest.Create(UrlCheck);
                    WebResponse res = req.GetResponse();
                    foreach (var item in Url)
                    {
                        dominio = item.Key.Split('/');
                        if (UrlCheck.Contains(dominio[0]))
                        {
                            Xpath = item.Value;
                            break;
                        }
                    }
                    if (!string.IsNullOrEmpty(Xpath))
                    {
                        var doc = new HtmlWeb().Load(UrlCheck);
                        var nodes = doc.DocumentNode.SelectSingleNode(Xpath).Descendants("p");
                        foreach (var node in nodes)
                        {
                            prova = prova + HttpUtility.HtmlDecode(node.InnerText);
                        }
                        Html.IsEnabled = true;
                        Tab.IsEnabled = true;
                        Immagine.IsEnabled = true;
                        List<string> articolo = RimuoviPunteggiatura(ref prova);
                        SelezionaParole(ref articolo);
                        RimozioneEsclusi(prova);
                        OccorrenzePiùAlte();
                        ToStrong(ref doc,ref grassetto);
                        savetodb(prova,UrlCheck,ParoleChiave);
                    }
                    else
                    {
                        MessageBox.Show("Il sito non è compatibile",
                                "INCOMPATIBILITÀ",
                                MessageBoxButton.OK,
                                MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    if (ex.Message == "Riferimento a un oggetto non impostato su un'istanza di oggetto.")
                    {
                        MessageBox.Show("Il link non corrisponde ad un articolo",
                            "AVVISO",
                            MessageBoxButton.OK,
                             MessageBoxImage.Information);
                    }
                    
                    else
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Non hai inserito il link",
                            "ATTENZIONE",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning);
            }
        }

        private void LoadXpath(ref Dictionary<string, string> dic)
        {
            dic = new Dictionary<string, string>();
            string[] x = File.ReadAllLines("Xpath.txt");
            for (int i = 0; i < x.Length; i++)
            {
                string[] tmp = x[i].Split(';');
                dic.Add(tmp[0], tmp[1]);
            }
        }

        //Metodo per togliere la punteggiatura
        private List<string> RimuoviPunteggiatura(ref string prova)
        {
            List<string> ris = new List<string>();
            prova = prova.Replace(Environment.NewLine, " ");
            prova = prova.Replace("\r", " ");
            prova = prova.Replace("\n", " ");
            prova = prova.Replace("\u00A0", " ");
            prova = prova.Replace('’', ' ');
            prova = prova.Replace('"', ' ');
            prova = prova.Replace('\'', ' ');
            string[] vet = prova.Split(' ');
            Testo.Text = prova;
            for (int i = 0; i < vet.Length; i++)
            {
                if (vet[i] != "" && vet[i] != null)
                {
                    if (char.TryParse(vet[i], out char c))
                    {
                        if (!char.IsPunctuation(c))
                        {
                            ris.Add(Convert.ToString(c));
                        }
                    }
                    else
                    {   //Rimuovere caratteri speciali --> % - _
                        string output;
                        if (vet[i].Contains('%') || vet[i].Contains('-') || vet[i].Contains('_'))
                        {
                            output = vet[i];
                            if (char.IsPunctuation(char.Parse(output.Substring(output.Length - 1, 1))) && output.Substring(output.Length - 1, 1) != "%")
                            {
                                ris.Add(output.Substring(0, output.Length - 1));
                            }
                            else
                            {
                                ris.Add(output);
                            }
                        }
                        else if (Decimal.TryParse(vet[i], out decimal d))
                        {
                            output = Convert.ToString(d);
                            ris.Add(output);
                        }
                        else
                        {
                            output = new string((vet[i].Where(c2 => char.IsLetterOrDigit(c2))).ToArray());
                            ris.Add(output);
                        }
                    }
                }
            }
            return ris;
        }

        private void SelezionaParole(ref List<string> lista)
        {
            Occorrenze = new Dictionary<string, uint>();
            for (int i = 0; i < lista.Count; i++)
            {
                if (Occorrenze.ContainsKey(lista[i].ToUpper()))
                {
                    Occorrenze.TryGetValue(lista[i].ToUpper(), out uint num);
                    Occorrenze[lista[i].ToUpper()] = num + 1;
                }
                else
                {
                    Occorrenze.Add(lista[i].ToUpper(), 1);
                }
            }
        }

        private void RimozioneEsclusi(string prova)
        {
            string[] esclusi = File.ReadAllLines("esclusi"+dominio[1]+".txt");
            for (int i = 0; i < esclusi.Length; i++)
            {
                if (Occorrenze.ContainsKey(esclusi[i].ToUpper()) || !string.IsNullOrWhiteSpace(esclusi[i].ToUpper()) || !string.IsNullOrEmpty(esclusi[i].ToUpper()))
                {
                    if (esclusi[i].Length == 1)
                    {
                        char.TryParse(esclusi[i], out char result);

                        if (!char.IsSeparator(result))
                        {
                            Occorrenze.Remove(esclusi[i].ToUpper());
                        }
                    }
                    else
                    {
                        Occorrenze.Remove(esclusi[i].ToUpper());
                    }
                }
            }
        }

        private void Tab_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new MyDialog(Occorrenze);
            dialog.ShowDialog();
        }

        //Attraverso l'HtmlAgilityPack riusciamo a prendere il contenuto della pagina web.
        private void Html_Click(object sender, RoutedEventArgs e)
        {
            HtmlAgilityPack.HtmlDocument HtmlDoc = new HtmlAgilityPack.HtmlDocument();
            HtmlDocument doc = new HtmlWeb().Load(UrlCheck);
            var dialogHtml = new html(ref grassetto);
            dialogHtml.ShowDialog();
        }

        //Metodo per trovare le occorrenze dentro al testo dell'Articolo

        private List<string> OccorrenzePiùAlte()
        {
            uint i = Occorrenze.Values.Max(), conta = 0;
            bool aggiunto = false;
            ParoleChiave = new List<string>();
            foreach (KeyValuePair<string, uint> y in Occorrenze.OrderByDescending(key => key.Value))
            {
                if (y.Value!=1)
                {
                Aggiungi:
                    if (i == y.Value)
                    {
                        ParoleChiave.Add(y.Key);
                        if (aggiunto == true)
                        {
                            conta++;
                        }
                        aggiunto = false;
                    }
                    else if (conta <= 2)
                    {
                        i--;
                        aggiunto = true;
                        goto Aggiungi;
                    }
                    if ((conta > 2)||(y.Value < 2))
                    {
                        break;
                    }
                }
                else
                {
                    break;
                }
            }
            return ParoleChiave;
        }
        
        //Passando le occorrenze si avrà il WordCloud delle parole.
        private void Immagine_Click(object sender, RoutedEventArgs e)
        {
            WordCloud wc = new WordCloud(Occorrenze);
            wc.ShowDialog();
        }

        //Metodo per salvare i dati nel db.
        
        private void savetodb(string testo, string link, List<string> pc)
        {
            string path = Environment.CurrentDirectory;
            path = path.Substring(0, path.Length - 9);
            string connectionstring = string.Format(@"Server=(localdb)\MSSQLLocalDB;AttachDbFilename="+path+"Database.mdf;Integrated Security=True;Persist Security Info=False;Pooling=False;MultipleActiveResultSets=False;Encrypt=False;TrustServerCertificate=False"); 
            SqlConnection SC = new SqlConnection(connectionstring);
            SqlCommand cmd = new SqlCommand("dbo.art_insert", SC);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.Add("@link", SqlDbType.NVarChar).Value = link;
            cmd.Parameters.Add("@testo", SqlDbType.NVarChar).Value = testo;
            cmd.Parameters.Add("@html", SqlDbType.NVarChar).Value = grassetto;
            SC.Open();
            cmd.ExecuteNonQuery();
            SC.Close();
            string word = "";
            for (int i = 0; i < pc.Count; i++)
            {
                word = pc[i];
                SqlCommand cmd2 = new SqlCommand("dbo.kw_insert", SC);
                cmd2.CommandType = System.Data.CommandType.StoredProcedure;
                cmd2.Parameters.Add("@kw", SqlDbType.NVarChar).Value = word;
                cmd2.Parameters.Add("@link", SqlDbType.NVarChar).Value = link;
                SC.Open();
                cmd2.ExecuteNonQuery();
                SC.Close();
            }
        }

        public static void databaseFilePut(string varFilePath)
        {

        }

        //Riapre il sito selezionato dalla lista dei siti
        private void ListaSiti_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool stop = false;
            string[] hp = File.ReadAllLines("Homepage.txt");
            string nomesito = " ";
            if (ListaSiti.SelectedIndex > -1)
            {
                for (int i = 0; i < ListaSiti.Items.Count; i++)
                {
                    nomesito = "";
                    stop = false;
                    foreach (char c in hp[i])
                    {
                        if ((c != '.') && (stop == true))
                        {
                            nomesito += c;
                        }
                        else if ((c == '.') && (stop == false))
                        {
                            stop = true;
                        }
                        else if ((c == '.') && (stop == true))
                        {
                            break;
                        }
                        if (string.Compare(nomesito, (string)ListaSiti.SelectedItem) == 0)
                        {
                            Process.Start("chrome.exe", hp[i]);
                        }
                    }

                }
            }
        }

        private void FromDb_Click(object sender, RoutedEventArgs e)
        {
            GetFromDb gf = new GetFromDb();
            gf.ShowDialog();
        }
    }
}
