﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Web;
using HtmlAgilityPack;
using System.Net;
using System.Web.UI.HtmlControls;
using System.Xml;
using mshtml;
using System.Reflection;

namespace Riminesi
{
    /// <summary>
    /// Logica di interazione per html.xaml
    /// </summary>
    public partial class html : Window
    {
        public html(ref string sos)
        {
            InitializeComponent();
            br.Navigated += (a, b) => { HideScriptErrors(br, true); };
            br.NavigateToString(sos);

        }
        //Metodo per nascondere gli script.
        public void HideScriptErrors(WebBrowser wb, bool hide)
        {
            var fiComWebBrowser = typeof(WebBrowser).GetField("_axIWebBrowser2", BindingFlags.Instance | BindingFlags.NonPublic);
            if (fiComWebBrowser == null) return;
            var objComWebBrowser = fiComWebBrowser.GetValue(wb);
            if (objComWebBrowser == null)
            {
                wb.Loaded += (o, s) => HideScriptErrors(wb, hide);
                return;
            }
            objComWebBrowser.GetType().InvokeMember("Silent", BindingFlags.SetProperty, null, objComWebBrowser, new object[] { hide });
        }
        
    }
}
